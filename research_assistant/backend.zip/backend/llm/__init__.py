"""
llm
---
Chat-model backends behind one interface, chosen by ``LLM_PROVIDER``:

  • "api"   → :class:`ApiLLM`, any OpenAI-compatible endpoint (default)
  • "local" → :class:`backend.llm.local_model.LocalLLM`, Qwen2.5 + QLoRA adapter on CPU
"""

from __future__ import annotations

from typing import Protocol

from openai import OpenAI

from backend.config import get_settings


class LLM(Protocol):
    """Anything that turns chat messages into a reply."""

    def generate(
        self, messages: list[dict[str, str]], max_tokens: int = 512, temperature: float = 0.0
    ) -> str: ...


class ApiLLM:
    """OpenAI-compatible chat endpoint (OpenAI, Gemini compat, Groq, Ollama).

    Raises:
        EnvironmentError: If ``LLM_API_KEY`` is not set.
    """

    def __init__(self) -> None:
        settings = get_settings()
        if settings.llm_api_key is None or not settings.llm_api_key.get_secret_value():
            raise EnvironmentError("LLM_API_KEY is not set. Copy .env.example → .env and fill in your key.")
        self.model: str = settings.llm_model
        self.client = OpenAI(api_key=settings.llm_api_key.get_secret_value(), base_url=settings.llm_base_url)

    def generate(
        self, messages: list[dict[str, str]], max_tokens: int = 512, temperature: float = 0.0
    ) -> str:
        response = self.client.chat.completions.create(
            model=self.model, messages=messages, temperature=temperature, max_tokens=max_tokens
        )
        return (response.choices[0].message.content or "").strip()


_llm: LLM | None = None


def get_llm() -> LLM:
    """Return the process-wide LLM for ``settings.llm_provider`` (built on first use)."""
    global _llm
    if _llm is None:
        if get_settings().llm_provider == "local":
            from backend.llm.local_model import LocalLLM  # heavy: torch + peft

            _llm = LocalLLM()
        else:
            _llm = ApiLLM()
    return _llm


__all__ = ["LLM", "ApiLLM", "get_llm"]

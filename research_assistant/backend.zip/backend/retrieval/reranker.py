"""
reranker.py
-----------
Custom PyTorch cross-encoder for second-stage reranking.

A pretrained encoder reads the pair ``[CLS] query [SEP] passage [SEP]``; the
[CLS] vector goes through dropout and a linear head to give one relevance
score. Trained weights (see ``backend/training/train_reranker.py``) are
loaded from ``settings.reranker_path``.
"""

from __future__ import annotations

import logging
from pathlib import Path

import torch
from torch import nn
from transformers import AutoModel, AutoTokenizer, PreTrainedTokenizerBase

from backend.config import get_settings
from backend.ingestion import Chunk

log = logging.getLogger(__name__)


class CrossEncoder(nn.Module):
    """Encoder + dropout + linear head scoring (query, passage) pairs.

    Args:
        model_name: HuggingFace encoder ID. Defaults to ``settings.reranker_model``.
        encoder: Prebuilt encoder (skips loading ``model_name``; used in tests).
        tokenizer: Prebuilt tokenizer matching ``encoder``.
        dropout: Dropout probability on the [CLS] vector.
        max_length: Maximum tokens per pair. Defaults to ``settings.reranker_max_length``.
    """

    def __init__(
        self,
        model_name: str | None = None,
        encoder: nn.Module | None = None,
        tokenizer: PreTrainedTokenizerBase | None = None,
        dropout: float = 0.1,
        max_length: int | None = None,
    ) -> None:
        super().__init__()
        settings = get_settings()
        self.model_name: str = model_name or settings.reranker_model
        self.max_length: int = max_length or settings.reranker_max_length
        self.encoder: nn.Module = encoder or AutoModel.from_pretrained(self.model_name)
        self.tokenizer: PreTrainedTokenizerBase = tokenizer or AutoTokenizer.from_pretrained(
            self.model_name
        )
        self.dropout = nn.Dropout(dropout)
        self.head = nn.Linear(self.encoder.config.hidden_size, 1)

    @property
    def device(self) -> torch.device:
        return self.head.weight.device

    def tokenize(self, queries: list[str], passages: list[str]) -> dict[str, torch.Tensor]:
        """Tokenize pairs as ``query [SEP] passage``, truncating the passage only.

        Args:
            queries: One query per pair.
            passages: One passage per pair.

        Returns:
            Padded tensors (``input_ids``, ``attention_mask``, ...) on CPU.
        """
        return dict(
            self.tokenizer(
                queries,
                passages,
                padding=True,
                truncation="only_second",
                max_length=self.max_length,
                return_tensors="pt",
            )
        )

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Score a batch of tokenized pairs.

        Returns:
            Tensor of shape ``(batch,)`` with one relevance score per pair.
        """
        out = self.encoder(
            input_ids=input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids
        )
        cls = out.last_hidden_state[:, 0]
        return self.head(self.dropout(cls)).squeeze(-1)

    @torch.no_grad()
    def score(self, query: str, passages: list[str], batch_size: int = 32) -> list[float]:
        """Relevance scores for ``query`` against each passage (eval mode)."""
        self.eval()
        scores: list[float] = []
        for i in range(0, len(passages), batch_size):
            batch = passages[i : i + batch_size]
            enc = {k: v.to(self.device) for k, v in self.tokenize([query] * len(batch), batch).items()}
            scores.extend(self(**enc).tolist())
        return scores

    def rerank(self, query: str, chunks: list[Chunk], top_k: int = 5) -> list[tuple[Chunk, float]]:
        """Sort chunks by cross-encoder score.

        Args:
            query: The user query.
            chunks: Candidate chunks (e.g. first-stage vector-search hits).
            top_k: Number of chunks to keep.

        Returns:
            ``(chunk, score)`` pairs, highest score first.
        """
        if not chunks:
            return []
        scores = self.score(query, [c.text for c in chunks])
        ranked = sorted(zip(chunks, scores), key=lambda pair: pair[1], reverse=True)
        return ranked[:top_k]

    def save(self, path: str | Path) -> None:
        """Save weights plus the encoder name to ``path``."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save({"model_name": self.model_name, "state_dict": self.state_dict()}, path)


def load_reranker(path: str | Path | None = None) -> CrossEncoder | None:
    """Load a trained reranker.

    Args:
        path: Checkpoint file. Defaults to ``settings.reranker_path``.

    Returns:
        The model in eval mode, or ``None`` if no checkpoint exists.
    """
    path = Path(path or get_settings().reranker_path)
    if not path.exists():
        return None
    ckpt = torch.load(path, map_location="cpu", weights_only=True)
    model = CrossEncoder(model_name=ckpt["model_name"])
    model.load_state_dict(ckpt["state_dict"])
    model.to("cuda" if torch.cuda.is_available() else "cpu").eval()
    log.info("Loaded reranker from %s", path)
    return model


_reranker: CrossEncoder | None = None


def get_reranker() -> CrossEncoder | None:
    """Process-wide trained reranker, or ``None`` if none has been trained yet.

    A missing checkpoint is not cached, so a model trained while the server
    runs is picked up on the next call.
    """
    global _reranker
    if _reranker is None:
        _reranker = load_reranker()
    return _reranker

"""
react.py
--------
ReAct agent: the LLM alternates ``Thought`` / ``Action`` (a JSON tool call)
with tool ``Observation``s until it writes a ``Final Answer``.

Malformed replies (bad JSON, unknown tool, bad args) are fed back as
Observations instead of raising. After ``agent_max_steps`` tool steps the
model is told to answer with what it has.
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from backend.agent.memory import Citation, Session, SessionStore, Turn
from backend.agent.tools import Tool, default_tools, truncate
from backend.config import get_settings
from backend.eval.faithfulness import FaithfulnessResult
from backend.llm import LLM, get_llm

log = logging.getLogger(__name__)

PROMPT_OBS_CHARS = 6000  # observation size sent back to the LLM
STEP_OBS_CHARS = 500  # observation size kept in the returned steps
MAX_TOKENS = 1024

SYSTEM_TEMPLATE = """You are ScholarPulse, a research assistant that reasons step by step and calls tools.

Tools (args are JSON):
{tools}

Rules:
- For questions about uploaded papers, call rag_search first.
- If local documents lack the needed context, call paper_search (ingest=true makes full papers searchable; then call rag_search again).
- Use python_interpreter for any arithmetic or statistics; never compute in your head.
- Cite every factual claim as [Doc N, Sec S], using the Doc and Sec labels from rag_search results. Never invent a citation.
- Call one tool per reply, then stop and wait for its Observation.

Reply in exactly one of these two formats:

Thought: <your reasoning>
Action: {{"tool": "<tool name>", "args": {{...}}}}

Thought: <your reasoning>
Final Answer: <Markdown answer with citations>"""

FORCE_FINAL = (
    "You have reached the step limit. Do not call any more tools. "
    "Reply now with 'Final Answer:' using only the information gathered so far."
)

_OBS_RE = re.compile(r"^\s*Observation\s*:", re.M | re.I)
_ACTION_RE = re.compile(r"^\s*Action\s*:", re.M | re.I)
_FINAL_RE = re.compile(r"^\s*Final Answer\s*:", re.M | re.I)
_THOUGHT_RE = re.compile(r"Thought\s*:\s*(.*?)(?=^\s*(?:Action|Final Answer)\s*:|\Z)", re.S | re.I | re.M)
_FIGURES_RE = re.compile(r"^Saved figures: (.+)$", re.M)
_CITE_RE = re.compile(r"\[Doc\s*(\d+)(?:\s*,\s*Sec\.?\s*([^,\]]+?))?(?:\s*,\s*p\.?\s*\d+)?\s*\]", re.I)


class ToolCall(BaseModel):
    tool: str
    args: dict[str, Any] = Field(default_factory=dict)


class ParsedReply(BaseModel):
    """One LLM reply split into its parts. Exactly one of action/final/error is set."""

    thought: str = ""
    action: ToolCall | None = None
    final: str | None = None
    error: str | None = None


class AgentStep(BaseModel):
    thought: str
    tool: str | None
    args: dict[str, Any]
    observation: str
    images: list[str] = Field(default_factory=list, description="PNG paths saved by python_interpreter")


class AgentResult(BaseModel):
    answer: str
    citations: list[Citation]
    steps: list[AgentStep]
    faithfulness: FaithfulnessResult | None = None
    # Texts of the retrieved chunks the answer cites (all retrieved chunks if it cites none).
    # Used for the faithfulness check; not sent to clients.
    cited_chunks: list[str] = Field(default_factory=list, exclude=True)


def parse_reply(text: str) -> ParsedReply:
    """Parse a ReAct reply. Never raises; problems are returned in ``error``."""
    text = _OBS_RE.split(text, maxsplit=1)[0]  # drop any Observation the model hallucinated
    m = _THOUGHT_RE.search(text)
    thought = m.group(1).strip() if m else ""
    action, final = _ACTION_RE.search(text), _FINAL_RE.search(text)
    if final and (action is None or final.start() < action.start()):
        return ParsedReply(thought=thought, final=text[final.end():].strip())
    if action is None:
        return ParsedReply(thought=thought, error="Reply must contain either 'Action: {...}' or 'Final Answer: ...'.")
    raw = text[action.end():]
    start = raw.find("{")
    try:
        if start == -1:
            raise json.JSONDecodeError("no JSON object found", raw, 0)
        obj, _ = json.JSONDecoder().raw_decode(raw[start:])
    except json.JSONDecodeError as exc:
        return ParsedReply(
            thought=thought,
            error=f'Invalid Action JSON ({exc.msg}). Use Action: {{"tool": "<name>", "args": {{...}}}}',
        )
    if not isinstance(obj, dict) or not isinstance(obj.get("tool"), str) or not isinstance(obj.get("args", {}), dict):
        return ParsedReply(thought=thought, error='Action must be {"tool": "<name>", "args": {...}}.')
    return ParsedReply(thought=thought, action=ToolCall(tool=obj["tool"], args=obj.get("args", {})))


def extract_citations(answer: str, session: Session) -> list[Citation]:
    """Resolve ``[Doc N, Sec S]`` markers in ``answer`` against the session's sources.

    Unknown doc numbers (hallucinated citations) are dropped with a warning.
    """
    found: list[Citation] = []
    for m in _CITE_RE.finditer(answer):
        n, sec = int(m.group(1)), (m.group(2) or "").strip()
        candidates = [c for c in session.sources if c.doc == n]
        match = next((c for c in candidates if sec and (c.section or "").casefold() == sec.casefold()), None)
        if match is None and candidates:
            match = candidates[0]
        if match is None:
            doc_id = session.doc_id_for(n)
            if doc_id is None:
                log.warning("Answer cites unknown Doc %d", n)
                continue
            match = Citation(doc=n, title=session.title_for(doc_id), section=sec or None)
        if match not in found:
            found.append(match)
    return found


class ReActAgent:
    """Runs one ReAct conversation turn per :meth:`chat` call.

    Args:
        llm: Chat model. Defaults to :func:`get_llm`.
        store: Session persistence. Defaults to ``SessionStore()``.
        tool_factory: Builds the tools for a session. Defaults to :func:`default_tools`.
        max_steps: Tool-step limit. Defaults to ``settings.agent_max_steps``.
        history_turns: Past turns included in the prompt. Defaults to ``settings.agent_history_turns``.
    """

    def __init__(
        self,
        llm: LLM | None = None,
        store: SessionStore | None = None,
        tool_factory: Callable[[Session], list[Tool]] | None = None,
        max_steps: int | None = None,
        history_turns: int | None = None,
    ) -> None:
        settings = get_settings()
        self.llm: LLM = llm or get_llm()
        self.store: SessionStore = store or SessionStore()
        self.tool_factory = tool_factory or default_tools
        self.max_steps: int = max_steps if max_steps is not None else settings.agent_max_steps
        self.history_turns: int = history_turns if history_turns is not None else settings.agent_history_turns

    def _messages(self, session: Session, tools: dict[str, Tool], message: str) -> list[dict[str, str]]:
        listing = "\n".join(f"- {t.name}{t.signature()}: {t.description}" for t in tools.values())
        messages = [{"role": "system", "content": SYSTEM_TEMPLATE.format(tools=listing)}]
        for turn in session.turns[-self.history_turns:] if self.history_turns > 0 else []:
            messages += [{"role": "user", "content": turn.user}, {"role": "assistant", "content": turn.assistant}]
        messages.append({"role": "user", "content": message})
        return messages

    @staticmethod
    def _run_tool(tools: dict[str, Tool], call: ToolCall) -> str:
        tool = tools.get(call.tool)
        if tool is None:
            return f"Error: unknown tool '{call.tool}'. Available tools: {', '.join(tools)}."
        try:
            return tool(call.args)
        except ValidationError as exc:
            errs = "; ".join(f"{'.'.join(map(str, e['loc'])) or 'args'}: {e['msg']}" for e in exc.errors())
            return f"Error: invalid args for {call.tool}: {errs}. Expected {tool.signature()}."
        except Exception as exc:  # noqa: BLE001 — tool failures become observations
            log.exception("Tool %s failed", call.tool)
            return f"Error: {call.tool} failed: {exc}"

    def chat(self, session_id: str, message: str) -> AgentResult:
        """Answer ``message`` in ``session_id``'s conversation and save the turn.

        Raises:
            ValueError: If ``session_id`` is malformed.
        """
        session = self.store.load(session_id)
        tools = {t.name: t for t in self.tool_factory(session)}
        messages = self._messages(session, tools, message)
        steps: list[AgentStep] = []
        answer: str | None = None

        for _ in range(self.max_steps):
            reply = self.llm.generate(messages, max_tokens=MAX_TOKENS, temperature=0.0)
            parsed = parse_reply(reply)
            messages.append({"role": "assistant", "content": _OBS_RE.split(reply, maxsplit=1)[0].strip()})
            if parsed.final is not None:
                answer = parsed.final
                break
            if parsed.action is not None:
                observation = self._run_tool(tools, parsed.action)
                tool, args = parsed.action.tool, parsed.action.args
            else:
                observation, tool, args = f"Error: {parsed.error}", None, {}
            log.info("Agent step %d: tool=%s", len(steps) + 1, tool)
            images = [p.strip() for m in _FIGURES_RE.finditer(observation) for p in m.group(1).split(",")]
            steps.append(AgentStep(thought=parsed.thought, tool=tool, args=args,
                                   observation=truncate(observation, STEP_OBS_CHARS), images=images))
            messages.append({"role": "user", "content": f"Observation: {truncate(observation, PROMPT_OBS_CHARS)}"})

        if answer is None:
            log.info("Step limit (%d) reached; forcing a final answer", self.max_steps)
            messages.append({"role": "user", "content": FORCE_FINAL})
            reply = self.llm.generate(messages, max_tokens=MAX_TOKENS, temperature=0.0)
            parsed = parse_reply(reply)
            answer = parsed.final if parsed.final is not None else (parsed.thought or reply.strip())

        citations = extract_citations(answer, session)
        session.turns.append(Turn(user=message, assistant=answer))
        self.store.save(session)
        retrieved = [rc for t in tools.values() for rc in getattr(t, "retrieved", [])]
        cited_docs = {c.doc for c in citations}
        texts = [ch.text for n, ch in retrieved if n in cited_docs] or [ch.text for _, ch in retrieved]
        return AgentResult(answer=answer, citations=citations, steps=steps, cited_chunks=list(dict.fromkeys(texts)))

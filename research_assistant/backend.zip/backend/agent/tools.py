"""
tools.py
--------
Tools the ReAct agent can call. Each has a ``name``, a ``description``, a
pydantic ``args_model`` (its JSON arguments) and ``run(args) -> str``.

  • rag_search         → reranked chunks from the local vector store
  • paper_search       → arXiv + Semantic Scholar, optionally ingesting PDFs
  • python_interpreter → runs Python in a subprocess (NOT a security sandbox)
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import uuid
from abc import ABC, abstractmethod
from collections.abc import Callable
from pathlib import Path
from typing import Any, ClassVar

from pydantic import BaseModel, Field

from backend.agent.memory import Citation, Session
from backend.config import get_settings
from backend.eval.guardrails import sanitize_text
from backend.ingestion import Chunk

log = logging.getLogger(__name__)

MAX_OUTPUT_CHARS = 4000
ABSTRACT_CHARS = 300
MAX_INGEST = 3

RetrieveFn = Callable[[str, int], list[tuple[Chunk, float]]]


def truncate(text: str, limit: int) -> str:
    """Cut ``text`` to ``limit`` characters, marking the cut."""
    return text if len(text) <= limit else text[:limit] + f"\n... [truncated {len(text) - limit} chars]"


class Tool(ABC):
    """Base class for agent tools."""

    name: ClassVar[str]
    description: ClassVar[str]
    args_model: ClassVar[type[BaseModel]]

    def signature(self) -> str:
        """Compact JSON-args description for the system prompt, e.g. ``{"query": str, "k": int=5}``."""
        parts = []
        for field, info in self.args_model.model_fields.items():
            ann = getattr(info.annotation, "__name__", str(info.annotation))
            default = "" if info.is_required() else f"={info.default!r}"
            parts.append(f'"{field}": {ann}{default}')
        return "{" + ", ".join(parts) + "}"

    def __call__(self, args: dict[str, Any]) -> str:
        """Validate ``args`` and run the tool.

        Raises:
            pydantic.ValidationError: If ``args`` don't match ``args_model``.
        """
        return self.run(self.args_model.model_validate(args))

    @abstractmethod
    def run(self, args: Any) -> str:
        """Execute with validated arguments and return the observation text."""


# ── rag_search ───────────────────────────────────────────────────────────────


class RagSearchArgs(BaseModel):
    query: str = Field(..., min_length=1)
    k: int = Field(5, ge=1, le=10)


def _default_retrieve(query: str, k: int) -> list[tuple[Chunk, float]]:
    from backend.retrieval.search import retrieve  # heavy: chromadb + torch

    return retrieve(query, k=k, rerank=True)


def _uploaded_names() -> dict[str, str]:
    """doc_id -> original filename of uploaded PDFs (empty if none recorded)."""
    try:
        return json.loads(get_settings().doc_names_file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


class RagSearchTool(Tool):
    """Searches ingested papers and numbers documents stably within the session.

    Args:
        session: Conversation whose ``Doc N`` numbering and sources are updated.
        retrieve_fn: ``(query, k) -> [(chunk, score)]``; defaults to reranked retrieval.
    """

    name = "rag_search"
    description = "Search the locally ingested/uploaded papers. Returns passages labelled [Doc N, Sec S, p.P]."
    args_model = RagSearchArgs

    def __init__(self, session: Session, retrieve_fn: RetrieveFn | None = None) -> None:
        self.session = session
        self.retrieve_fn: RetrieveFn = retrieve_fn or _default_retrieve
        self.retrieved: list[tuple[int, Chunk]] = []  # (Doc N, chunk) seen this turn

    def run(self, args: RagSearchArgs) -> str:
        hits = self.retrieve_fn(args.query, args.k)
        if not hits:
            return "No matching passages in local documents. Try paper_search with ingest=true."
        lines = []
        names = _uploaded_names()
        for chunk, _score in hits:
            n = self.session.doc_number(chunk.doc_id)
            if chunk.doc_id not in self.session.doc_titles and chunk.doc_id in names:
                self.session.doc_titles[chunk.doc_id] = names[chunk.doc_id]
            section = chunk.section or "n/a"
            self.session.add_source(
                Citation(doc=n, title=self.session.title_for(chunk.doc_id), page=chunk.page, section=chunk.section)
            )
            self.retrieved.append((n, chunk))
            # Strip injected instructions hidden in documents before the LLM sees them.
            lines.append(f"[Doc {n}, Sec {section}, p.{chunk.page}] {sanitize_text(chunk.text).strip()}")
        return "\n\n".join(lines)


# ── paper_search ─────────────────────────────────────────────────────────────


class PaperSearchArgs(BaseModel):
    query: str = Field(..., min_length=1)
    max_results: int = Field(5, ge=1, le=10)
    ingest: bool = False


class PaperSearchTool(Tool):
    """Searches arXiv / Semantic Scholar; with ``ingest`` also indexes the top PDFs.

    Args:
        session: Conversation that receives ``Doc N`` numbers and titles for ingested papers.
    """

    name = "paper_search"
    description = (
        "Search arXiv and Semantic Scholar for papers. With ingest=true, the top PDFs are "
        "downloaded and indexed so rag_search can read their full text."
    )
    args_model = PaperSearchArgs

    def __init__(self, session: Session) -> None:
        self.session = session

    def run(self, args: PaperSearchArgs) -> str:
        from backend.tools.web_search import SearchUnavailableError, search_papers

        try:
            papers = search_papers(args.query, max_results=args.max_results)
        except SearchUnavailableError as exc:
            return f"Error: paper search unavailable ({exc})"
        if not papers:
            return "No papers found."
        lines = []
        for i, p in enumerate(papers, 1):
            authors = ", ".join(p.authors[:3]) + (" et al." if len(p.authors) > 3 else "")
            lines.append(
                f"{i}. {p.title} ({p.year or 'n.d.'}) — {authors or 'unknown authors'}\n"
                f"   {truncate(p.abstract, ABSTRACT_CHARS)}"
            )
        if args.ingest:
            lines.append(self._ingest(papers[:MAX_INGEST]))
        return "\n".join(lines)

    def _ingest(self, papers: list[Any]) -> str:
        from backend.ingestion import ingest_pdf
        from backend.retrieval import get_vector_store
        from backend.tools.web_search import download_pdf

        done, failed = [], []
        for paper in papers:
            try:
                path = download_pdf(paper) if paper.pdf_url else None
                if path is None:
                    failed.append(paper.title)
                    continue
                chunks = ingest_pdf(path)
                get_vector_store().add_chunks(chunks)
                doc_id = chunks[0].doc_id
                self.session.doc_titles[doc_id] = paper.title
                done.append(f"Doc {self.session.doc_number(doc_id)}: {paper.title}")
            except Exception as exc:  # noqa: BLE001 — one bad PDF must not stop the rest
                log.warning("Ingest failed for %s: %s", paper.id, exc)
                failed.append(paper.title)
        msg = "Ingested (now searchable with rag_search): " + ("; ".join(done) or "none")
        return msg + (f"\nCould not ingest: {'; '.join(failed)}" if failed else "")


# ── python_interpreter ───────────────────────────────────────────────────────


class PythonArgs(BaseModel):
    code: str = Field(..., min_length=1)


def run_python(code: str, timeout: float | None = None, output_dir: str | Path | None = None) -> str:
    """Run ``code`` with the server's (venv) Python in a fresh temp directory.

    This is NOT a security sandbox: the code runs as the server user, can read
    and write files and open network connections. It only isolates the working
    directory and environment, and limits run time and output size.

    Args:
        code: Python source.
        timeout: Seconds before the process group is killed. Defaults to ``settings.python_timeout_seconds``.
        output_dir: Where saved ``.png`` files are copied. Defaults to ``settings.agent_output_dir``.

    Returns:
        Exit status, stdout and stderr (truncated to 4,000 chars), plus paths of saved PNGs.
    """
    settings = get_settings()
    timeout = timeout if timeout is not None else settings.python_timeout_seconds
    out_dir = Path(output_dir) if output_dir is not None else settings.agent_output_dir
    with tempfile.TemporaryDirectory(prefix="agent_py_") as tmp:
        script = Path(tmp) / "main.py"
        script.write_text(code, encoding="utf-8")
        env = {"PATH": os.defpath, "HOME": tmp, "MPLBACKEND": "Agg", "MPLCONFIGDIR": tmp}
        proc = subprocess.Popen(
            [sys.executable, "-I", str(script)],
            cwd=tmp,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,  # own process group, so children die with it
        )
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
            status = f"exit code {proc.returncode}"
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            stdout, stderr = proc.communicate()
            status = f"Error: timed out after {timeout:g} s (process killed)"
        saved = []
        for png in sorted(Path(tmp).rglob("*.png")):
            out_dir.mkdir(parents=True, exist_ok=True)
            dest = out_dir / f"{uuid.uuid4().hex[:8]}_{png.name}"
            shutil.copy2(png, dest)
            saved.append(str(dest.resolve()))
    text = f"{status}\n--- stdout ---\n{stdout}"
    if stderr:
        text += f"\n--- stderr ---\n{stderr}"
    text = truncate(text, MAX_OUTPUT_CHARS)
    if saved:
        text += "\nSaved figures: " + ", ".join(saved)
    return text


class PythonInterpreterTool(Tool):
    """Executes Python for arithmetic, statistics and plots (see :func:`run_python`)."""

    name = "python_interpreter"
    description = (
        "Run a Python script (15 s limit, no input). Use print() to show results; "
        "numpy/pandas/matplotlib may be available. Saved .png files are returned as paths."
    )
    args_model = PythonArgs

    def run(self, args: PythonArgs) -> str:
        return run_python(args.code)


def default_tools(session: Session) -> list[Tool]:
    """The standard tool set bound to ``session``."""
    return [RagSearchTool(session), PaperSearchTool(session), PythonInterpreterTool()]

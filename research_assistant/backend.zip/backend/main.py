"""
main.py
-------
FastAPI application exposing two endpoints:

  POST /research          → Enqueue a background research job, return job_id
  GET  /research/{job_id} → Poll current status and retrieve result

Jobs are stored in an in-memory dict (suitable for a single-process server).
For multi-process / multi-worker deployments, swap the in-memory store for
Redis or a lightweight DB in a future sprint.
"""

from __future__ import annotations

import logging
import uuid
from contextlib import asynccontextmanager
from typing import Any

import hashlib
import json
import shutil
import tempfile
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.agent import AgentResult, ReActAgent
from backend.config import get_settings
from backend.eval.faithfulness import check_faithfulness
from backend.eval.guardrails import detect_injection
from backend.ingestion import ingest_pdf
from backend.llm_researcher import run_research_query
from backend.retrieval import get_vector_store
from backend.retrieval.search import retrieve
from backend.tools.web_search import (
    ALL_SOURCES,
    Paper,
    SearchUnavailableError,
    Source,
    search_papers,
)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# In-memory job store
# ---------------------------------------------------------------------------
# Schema per job:
#   {
#     "status": "pending" | "running" | "completed" | "failed",
#     "topic":  str,
#     "result": str | None,
#     "error":  str | None,
#   }

jobs: dict[str, dict[str, Any]] = {}


# ---------------------------------------------------------------------------
# Background worker
# ---------------------------------------------------------------------------

def _run_job(job_id: str, topic: str) -> None:
    """Execute the LLM research query and update the job store."""
    log.info("Job %s started — topic: %r", job_id, topic)
    jobs[job_id]["status"] = "running"
    try:
        result = run_research_query(topic)
        jobs[job_id]["status"] = "completed"
        jobs[job_id]["result"] = result
        log.info("Job %s completed successfully", job_id)
    except Exception as exc:  # noqa: BLE001
        log.exception("Job %s failed: %s", job_id, exc)
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["error"] = str(exc)


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):  # noqa: ANN001
    log.info("Research Assistant API starting up")
    yield
    log.info("Research Assistant API shutting down")


app = FastAPI(
    title="AI Research Assistant API",
    description="Background LLM research job queue with status polling.",
    version="0.2.0",
    lifespan=lifespan,
)

# Allow the Streamlit frontend (any localhost origin) to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------

class ResearchRequest(BaseModel):
    topic: str = Field(..., min_length=3, max_length=500, description="Research topic")


class JobCreatedResponse(BaseModel):
    job_id: str
    status: str


class JobStatusResponse(BaseModel):
    job_id: str
    status: str
    topic: str
    result: str | None = None
    error: str | None = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.post(
    "/research",
    response_model=JobCreatedResponse,
    status_code=202,
    summary="Enqueue a background research job",
)
async def create_research_job(
    body: ResearchRequest,
    background_tasks: BackgroundTasks,
) -> JobCreatedResponse:
    """
    Accept a research topic, register a background worker, and immediately
    return a ``job_id`` without blocking.
    """
    job_id = str(uuid.uuid4())
    jobs[job_id] = {
        "status": "pending",
        "topic": body.topic,
        "result": None,
        "error": None,
    }
    background_tasks.add_task(_run_job, job_id, body.topic)
    log.info("Job %s enqueued — topic: %r", job_id, body.topic)
    return JobCreatedResponse(job_id=job_id, status="pending")


@app.get(
    "/research/{job_id}",
    response_model=JobStatusResponse,
    summary="Poll the status of a research job",
)
async def get_research_job(job_id: str) -> JobStatusResponse:
    """
    Return the current status and, once completed, the full Markdown result.
    """
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found")
    return JobStatusResponse(
        job_id=job_id,
        status=job["status"],
        topic=job["topic"],
        result=job.get("result"),
        error=job.get("error"),
    )


@app.get(
    "/search",
    response_model=list[Paper],
    summary="Search arXiv and Semantic Scholar for papers",
)
def search(  # sync def: FastAPI runs it in a threadpool, so blocking I/O is fine
    q: str = Query(..., min_length=1, max_length=500, description="Search query"),
    max_results: int = Query(10, ge=1, le=50, description="Maximum merged results"),
    sources: list[Source] = Query(list(ALL_SOURCES), description="Sources to query"),
) -> list[Paper]:
    """Return deduplicated papers. Responds 503 only if every source is down."""
    if not q.strip():
        raise HTTPException(status_code=422, detail="q must not be blank")
    try:
        return search_papers(q, max_results=max_results, sources=sources)
    except SearchUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


UPLOAD_DIR = Path("data/uploads")
CHUNKS_DIR = Path("data/chunks")
MAX_UPLOAD_BYTES = 50 * 1024 * 1024


def _load_doc_names() -> dict[str, str]:
    try:
        return json.loads(get_settings().doc_names_file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


class UploadResponse(BaseModel):
    doc_id: str
    filename: str
    chunk_count: int


@app.post(
    "/documents/upload",
    response_model=UploadResponse,
    summary="Upload a PDF, ingest it and return the chunk count",
)
def upload_document(file: UploadFile = File(...)) -> UploadResponse:
    """Store the PDF under data/uploads/<doc_id>.pdf and its chunks as JSONL."""
    filename = file.filename or "upload.pdf"
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=UPLOAD_DIR, suffix=".part", delete=False) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = Path(tmp.name)
    try:
        if tmp_path.stat().st_size > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413, detail="PDF larger than 50 MB")
        with tmp_path.open("rb") as fh:
            if fh.read(5) != b"%PDF-":
                raise HTTPException(status_code=400, detail=f"{filename} is not a PDF")
        doc_id = hashlib.sha256(tmp_path.read_bytes()).hexdigest()[:16]
        stored = tmp_path.replace(UPLOAD_DIR / f"{doc_id}.pdf")
        try:
            chunks = ingest_pdf(stored, out_dir=CHUNKS_DIR)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    finally:
        tmp_path.unlink(missing_ok=True)
    get_vector_store().add_chunks(chunks)
    names = _load_doc_names()
    names[doc_id] = filename
    get_settings().doc_names_file.write_text(json.dumps(names, indent=2), encoding="utf-8")
    log.info("Uploaded %s as %s (%d chunks indexed)", filename, doc_id, len(chunks))
    return UploadResponse(doc_id=doc_id, filename=filename, chunk_count=len(chunks))


class RagHit(BaseModel):
    chunk_id: str
    doc_id: str
    text: str
    page: int
    section: str | None
    score: float


@app.get(
    "/rag/search",
    response_model=list[RagHit],
    summary="Semantic search over uploaded document chunks",
)
def rag_search(
    q: str = Query(..., min_length=1, max_length=500, description="Search query"),
    k: int = Query(5, ge=1, le=50, description="Number of chunks to return"),
    doc_ids: list[str] | None = Query(None, description="Restrict to these doc_ids"),
    rerank: bool = Query(True, description="Rerank vector hits with the cross-encoder"),
) -> list[RagHit]:
    """Return the top-k chunks.

    With ``rerank``, fetch ``rerank_candidates`` (default 20) from ChromaDB and
    reorder them with the cross-encoder; scores are then reranker logits, not
    cosine similarities. Falls back to vector order if no model is trained.
    """
    if not q.strip():
        raise HTTPException(status_code=422, detail="q must not be blank")
    hits = retrieve(q, k=k, doc_ids=doc_ids, rerank=rerank)
    return [RagHit(**chunk.model_dump(), score=score) for chunk, score in hits]


class ChatRequest(BaseModel):
    session_id: str = Field(..., pattern=r"^[A-Za-z0-9_-]{1,64}$", description="Conversation ID")
    message: str = Field(..., min_length=1, max_length=4000)


_agent: ReActAgent | None = None


@app.post("/agent/chat", response_model=AgentResult, summary="Ask the ReAct research agent")
def agent_chat(body: ChatRequest) -> AgentResult:  # sync def: LLM + tools block, so run in threadpool
    """Run one agent turn; memory is kept per ``session_id`` under data/sessions/."""
    global _agent
    if not body.message.strip():
        raise HTTPException(status_code=422, detail="message must not be blank")
    phrase = detect_injection(body.message)
    if phrase is not None:
        log.warning("Rejected prompt-injection attempt in session %s: %r", body.session_id, phrase)
        raise HTTPException(
            status_code=400,
            detail=f"Message rejected by the prompt-injection filter (matched: \"{phrase}\"). "
            "Please rephrase your question.",
        )
    try:
        if _agent is None:
            _agent = ReActAgent()
        result = _agent.chat(body.session_id, body.message)
    except EnvironmentError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if result.cited_chunks:  # nothing to check against if the agent retrieved no passages
        result.faithfulness = check_faithfulness(result.answer, result.cited_chunks)
        if result.faithfulness.score < get_settings().faithfulness_warn_below:
            result.answer += (
                f"\n\n> ⚠️ Low faithfulness ({result.faithfulness.score:.0%}): "
                f"{len(result.faithfulness.unsupported)} sentence(s) are not well supported by the cited passages."
            )
    return result


class DocumentInfo(BaseModel):
    doc_id: str
    title: str
    chunk_count: int


@app.get("/documents", response_model=list[DocumentInfo], summary="List uploaded documents")
def list_documents() -> list[DocumentInfo]:
    """Uploaded PDFs, newest first; ``title`` is the original filename when known."""
    names = _load_doc_names()
    docs = []
    for pdf in sorted(UPLOAD_DIR.glob("*.pdf"), key=lambda p: p.stat().st_mtime, reverse=True):
        chunks = CHUNKS_DIR / f"{pdf.stem}.jsonl"
        count = sum(1 for _ in chunks.open(encoding="utf-8")) if chunks.exists() else 0
        docs.append(DocumentInfo(doc_id=pdf.stem, title=names.get(pdf.stem, pdf.name), chunk_count=count))
    return docs


@app.get("/health", summary="Health check")
async def health() -> dict[str, str]:
    return {"status": "ok"}


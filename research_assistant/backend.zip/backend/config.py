"""
config.py
---------
Central settings object for the ScholarPulse backend.

Values are read from environment variables and from ``research_assistant/.env``
(environment variables win). Modules should call :func:`get_settings` instead
of reading ``os.environ`` directly.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

_ENV_PATH = Path(__file__).resolve().parents[1] / ".env"


class Settings(BaseSettings):
    """Typed application settings loaded from the environment / ``.env``."""

    model_config = SettingsConfigDict(
        env_file=_ENV_PATH,
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── LLM (backend/llm/) ───────────────────────────────────────────────────
    # "api" = OpenAI-compatible endpoint below; "local" = base model + QLoRA adapter on CPU.
    llm_provider: Literal["api", "local"] = "api"
    llm_api_key: SecretStr | None = None
    llm_base_url: str = "https://api.openai.com/v1"
    llm_model: str = "gpt-4o-mini"
    local_base_model: str = "Qwen/Qwen2.5-1.5B-Instruct"
    local_adapter_dir: Path = Path("data/models/qlora_adapter")

    # ── Academic web search (backend/tools/web_search.py) ────────────────────
    semantic_scholar_api_key: SecretStr | None = None
    http_timeout_seconds: float = 20.0
    arxiv_delay_seconds: float = 3.0
    s2_max_retries: int = 4
    s2_backoff_base_seconds: float = 1.0
    s2_backoff_max_seconds: float = 30.0

    # ── On-disk search cache ─────────────────────────────────────────────────
    search_cache_enabled: bool = True
    search_cache_dir: Path = Path("data/cache/search")
    search_cache_ttl_seconds: int = 24 * 60 * 60

    # ── RAG retrieval (backend/retrieval/vector_store.py) ────────────────────
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    embedding_query_prefix: str = "Represent this sentence for searching relevant passages: "
    chroma_dir: Path = Path("data/chroma")
    chroma_collection: str = "chunks"

    # ── Cross-encoder reranker (backend/retrieval/reranker.py) ───────────────
    reranker_model: str = "microsoft/MiniLM-L12-H384-uncased"
    reranker_path: Path = Path("data/models/reranker.pt")
    reranker_max_length: int = 512
    rerank_candidates: int = 20

    # ── ReAct agent (backend/agent/) ─────────────────────────────────────────
    sessions_dir: Path = Path("data/sessions")
    agent_max_steps: int = 6
    agent_history_turns: int = 10
    agent_output_dir: Path = Path("data/agent_outputs")
    python_timeout_seconds: float = 15.0

    # ── Evaluation / guardrails (backend/eval/) ──────────────────────────────
    doc_names_file: Path = Path("data/uploads/names.json")  # doc_id -> uploaded filename
    faithfulness_threshold: float = 0.6
    faithfulness_warn_below: float = 0.7


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-wide :class:`Settings` instance (created once)."""
    return Settings()
